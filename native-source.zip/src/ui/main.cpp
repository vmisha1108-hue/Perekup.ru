// Native UI under construction. No browser, HTML renderer or JavaScript runtime.
#include <QApplication>
#include <QMainWindow>
#include <QMdiArea>
#include <QMdiSubWindow>
#include <QVBoxLayout>
#include <QHBoxLayout>
#include <QGridLayout>
#include <QLabel>
#include <QPushButton>
#include <QToolButton>
#include <QLineEdit>
#include <QComboBox>
#include <QScrollArea>
#include <QFileDialog>
#include <QMessageBox>
#include <QDialog>
#include <QTimer>
#include <QDateTime>
#include <QCalendarWidget>
#include <QPainter>
#include <QPixmap>
#include <QCloseEvent>
#include <QDir>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QSaveFile>
#include <QScreen>
#include <QKeyEvent>
#include <QResizeEvent>
#include <QFrame>
#include <QLocale>
#include <QTime>
#include <QElapsedTimer>
#include "game_clock.hpp"
#include "session.hpp"
#include "runtime.hpp"
#include <QFormLayout>
#include <QRegularExpressionValidator>
#include <QRegularExpression>
#include <QDialogButtonBox>
#include <future>
#include <memory>
#include <map>
#include <fstream>
#include <random>
#include "bank.hpp"
#include "snake.hpp"
#include "calculator.hpp"
using perekup::Json;
static QString qs(const std::string& s){return QString::fromUtf8(s.data(),int(s.size()));}
static QString money(double n){return QLocale(QLocale::Russian).toString(qint64(n))+QStringLiteral(" ₽");}
class Desktop:public QMdiArea {
 QPixmap wallpaper;
public:
 void setWallpaper(const QString& path){wallpaper.load(path);viewport()->update();}
protected:
 void paintEvent(QPaintEvent* event)override{QMdiArea::paintEvent(event);QPainter p(viewport());if(!wallpaper.isNull()){auto scaled=wallpaper.scaled(viewport()->size(),Qt::KeepAspectRatioByExpanding,Qt::SmoothTransformation);p.drawPixmap((width()-scaled.width())/2,(height()-scaled.height())/2,scaled);}else p.fillRect(viewport()->rect(),QColor("#192735"));}
};
class SnakeView:public QWidget {
 std::mt19937 generator{std::random_device{}()};
 perekup::Snake snake;QTimer timer;QElapsedTimer elapsed;
public:
 SnakeView():snake([this]{return std::generate_canonical<double,53>(generator);}){elapsed.start();setFocusPolicy(Qt::StrongFocus);setMinimumSize(350,390);connect(&timer,&QTimer::timeout,this,[this]{snake.frame(elapsed.elapsed(),isVisible());update();});timer.start(16);}
protected:
 void paintEvent(QPaintEvent*)override{QPainter p(this);p.fillRect(rect(),QColor("#f7f8f5"));int side=std::min(width()-32,height()-70),cell=side/22,x=(width()-cell*22)/2,y=44;p.fillRect(x,y,cell*22,cell*22,QColor("#e2e9e5"));p.setPen(QColor("#263036"));p.drawText(16,24,QStringLiteral("Счёт: %1    Пробел — старт / пауза").arg(snake.score));for(const auto& point:snake.body)p.fillRect(x+point.x*cell+1,y+point.y*cell+1,cell-2,cell-2,QColor("#14796f"));if(snake.hasFood)p.fillRect(x+snake.food.x*cell+1,y+snake.food.y*cell+1,cell-2,cell-2,QColor("#cc724e"));}
 void keyPressEvent(QKeyEvent* e)override{if(e->key()==Qt::Key_Space){if(snake.playing)snake.pause();else if(snake.ended||snake.last==0)snake.start(elapsed.elapsed());else snake.resume(elapsed.elapsed());}else if(e->key()==Qt::Key_Up)snake.turn(0,-1);else if(e->key()==Qt::Key_Down)snake.turn(0,1);else if(e->key()==Qt::Key_Left)snake.turn(-1,0);else if(e->key()==Qt::Key_Right)snake.turn(1,0);else QWidget::keyPressEvent(e);update();}
};
class CalculatorView:public QWidget {
 perekup::Calculator model;QLabel *history,*display;
 void press(const QString& key){model.key(key.toUtf8().toStdString());history->setText(qs(model.history));display->setText(qs(model.display));}
public:
 CalculatorView(){setFocusPolicy(Qt::StrongFocus);auto layout=new QVBoxLayout(this);history=new QLabel;history->setWordWrap(true);display=new QLabel("0");display->setAlignment(Qt::AlignRight);display->setStyleSheet("font-size:28px");display->setWordWrap(true);layout->addWidget(history);layout->addWidget(display);auto grid=new QGridLayout;QStringList keys={"C","←","÷","×","7","8","9","−","4","5","6","+","1","2","3","=","0",".","00","%"};for(int i=0;i<keys.size();++i){auto button=new QPushButton(keys[i]);button->setMinimumSize(50,42);button->setFocusPolicy(Qt::NoFocus);connect(button,&QPushButton::clicked,this,[this,key=keys[i]]{press(key);setFocus();});grid->addWidget(button,i/4,i%4);}layout->addLayout(grid);}
protected:
 void keyPressEvent(QKeyEvent* e)override{if(e->key()==Qt::Key_Return||e->key()==Qt::Key_Enter)press("=");else if(e->key()==Qt::Key_Backspace)press("←");else if(e->key()==Qt::Key_Escape)press("C");else if(e->text().size()==1&&QString("0123456789+-*/.()%").contains(e->text()))press(e->text());else QWidget::keyPressEvent(e);}
};
class Shell:public QMainWindow {
 std::unique_ptr<perekup::Session> session;bool closing=false,closeAllowed=false;std::shared_future<void> closingSave,autosave;int autosaveTicks=0;
 QString root;Desktop* desktop=nullptr;QWidget* dock=nullptr;QLabel* time=nullptr;
 Json catalog,citiesById,carsById,offersById=Json::object();std::string homeCity;bool runtimeFailed=false;QJsonObject preferences;
 perekup::GameClock gameClock{QDateTime::currentMSecsSinceEpoch(),QDateTime::currentMSecsSinceEpoch()};std::map<QString,QMdiSubWindow*> windows;
 QString selectedCity;QString search;QWidget* marketContent=nullptr;
 static QPushButton* button(const QString& title){auto b=new QPushButton(title);b->setMinimumHeight(32);b->setCursor(Qt::PointingHandCursor);return b;}
 QString settingsPath()const{return root+"/saves/native-ui.json";}
 bool savePreferences(){QDir().mkpath(root+"/saves");QSaveFile file(settingsPath());auto bytes=QJsonDocument(preferences).toJson();return file.open(QIODevice::WriteOnly)&&file.write(bytes)==bytes.size()&&file.commit();}
 void showError(const QString& message){QMessageBox::warning(this,QStringLiteral("Perekup"),message);}
 QMdiSubWindow* open(const QString& id,const QString& title,QWidget* body,QSize size){auto existing=windows.find(id);if(existing!=windows.end()){delete body;existing->second->showNormal();desktop->setActiveSubWindow(existing->second);return existing->second;}auto win=desktop->addSubWindow(body);win->setAttribute(Qt::WA_DeleteOnClose);win->setWindowTitle(title);win->resize(size);win->setMinimumSize(320,240);windows[id]=win;connect(win,&QObject::destroyed,this,[this,id]{windows.erase(id);if(id=="market")marketContent=nullptr;});win->show();return win;}
 void positionDock(){if(!dock)return;dock->adjustSize();dock->move((desktop->viewport()->width()-dock->width())/2,desktop->viewport()->height()-dock->height()-16);dock->raise();}
 void renderMarket(){if(!marketContent)return;auto layout=qobject_cast<QGridLayout*>(marketContent->layout());while(auto item=layout->takeAt(0)){delete item->widget();delete item;}int count=0;
 for(const auto& car:catalog.at("cars")){if(!selectedCity.isEmpty()&&qs(car.value("cityId",""))!=selectedCity)continue;auto name=qs(car.value("name",""));if(!search.isEmpty()&&!name.contains(search,Qt::CaseInsensitive))continue;
 auto card=new QFrame;card->setObjectName("card");auto vertical=new QVBoxLayout(card);vertical->setContentsMargins(0,0,0,12);auto photo=new QLabel;photo->setMinimumSize(190,135);photo->setMaximumHeight(165);photo->setAlignment(Qt::AlignCenter);QPixmap image(root+"/assets/"+qs(car.value("img","")));if(!image.isNull())photo->setPixmap(image.scaled(250,165,Qt::KeepAspectRatioByExpanding,Qt::SmoothTransformation));else photo->setText(QStringLiteral("Фото недоступно"));vertical->addWidget(photo);auto title=new QLabel(name);title->setWordWrap(true);title->setMargin(10);vertical->addWidget(title);auto price=new QLabel(money(car.value("price",0.)));price->setObjectName("price");price->setMargin(10);vertical->addWidget(price);auto description=new QLabel(qs(car.value("desc","")));description->setWordWrap(true);description->setMargin(10);vertical->addWidget(description);auto details=button(QStringLiteral("Подробнее"));vertical->addWidget(details);connect(details,&QPushButton::clicked,this,[this,car]{QDialog dialog(this);dialog.setWindowTitle(qs(car.value("name","")));auto l=new QVBoxLayout(&dialog);auto description=new QLabel(qs(car.value("full","")));description->setWordWrap(true);l->addWidget(description);auto close=button(QStringLiteral("Закрыть"));l->addWidget(close);connect(close,&QPushButton::clicked,&dialog,&QDialog::accept);dialog.resize(540,300);dialog.exec();});layout->addWidget(card,count/3,count%3);++count;
 }
 if(!count)layout->addWidget(new QLabel(QStringLiteral("По этим условиям объявлений нет.")),0,0);layout->setRowStretch((count+2)/3,1);
 }
 void market(){if(windows.count("market")){windows["market"]->showNormal();desktop->setActiveSubWindow(windows["market"]);return;}auto body=new QWidget;auto outer=new QHBoxLayout(body);outer->setContentsMargins(0,0,0,0);auto sidebar=new QWidget;sidebar->setObjectName("sidebar");sidebar->setFixedWidth(164);auto nav=new QVBoxLayout(sidebar);nav->addWidget(new QLabel(QStringLiteral("Авторынок")));auto all=button(QStringLiteral("Объявления"));nav->addWidget(all);nav->addStretch();nav->addWidget(new QLabel("PEREKUP OS"));outer->addWidget(sidebar);auto main=new QWidget;auto content=new QVBoxLayout(main);auto toolbar=new QHBoxLayout;auto cities=new QComboBox;cities->addItem(QStringLiteral("Все города"),QString());for(const auto& city:catalog.at("cities"))cities->addItem(qs(city.value("name","")),qs(city.value("id","")));auto query=new QLineEdit;query->setPlaceholderText(QStringLiteral("Марка или модель"));toolbar->addWidget(cities);toolbar->addWidget(query);content->addLayout(toolbar);auto scroll=new QScrollArea;scroll->setWidgetResizable(true);marketContent=new QWidget;auto grid=new QGridLayout(marketContent);grid->setSpacing(16);scroll->setWidget(marketContent);content->addWidget(scroll);outer->addWidget(main,1);connect(cities,qOverload<int>(&QComboBox::currentIndexChanged),this,[this,cities]{selectedCity=cities->currentData().toString();renderMarket();});connect(query,&QLineEdit::textChanged,this,[this](const QString& value){search=value;renderMarket();});connect(all,&QPushButton::clicked,this,[cities,query]{cities->setCurrentIndex(0);query->clear();});open("market",QStringLiteral("Авторынок"),body,QSize(1050,720));renderMarket();}
 void bankAction(const std::function<bool(perekup::Bank&)>& action){
 if(closing||!session||!session->ready())return;
 try{auto draft=session->state;perekup::Bank bank([]{static std::mt19937 generator{std::random_device{}()};return std::generate_canonical<double,53>(generator);});bank.state=draft.at("bank");bank.balance=draft.at("balance");bank.now=draft.at("gameMs").get<double>();bank.gameOver=draft.at("marketRisks").at("seizures").size()>=5;if(!action(bank)){showError(QStringLiteral("Операция недоступна. Проверьте сумму, баланс и состояние заявки."));return;}draft["bank"]=bank.state;draft["balance"]=bank.balance;session->commit(draft);}catch(const std::exception& e){showError(QStringLiteral("Операция не сохранена.\n")+QString::fromUtf8(e.what()));}}
 void bankApp(){auto body=new QWidget;auto layout=new QVBoxLayout(body);auto balance=new QLabel;balance->setObjectName("heading");layout->addWidget(balance);auto status=new QLabel;status->setWordWrap(true);layout->addWidget(status);auto row=new QHBoxLayout;auto amount=new QComboBox;for(auto n:perekup::Bank::amounts)amount->addItem(money(n),QVariant::fromValue<qlonglong>(n));auto term=new QComboBox;for(auto n:perekup::Bank::terms)term->addItem(QStringLiteral("%1 месяцев").arg(n),n);row->addWidget(amount);row->addWidget(term);layout->addLayout(row);auto request=button(QStringLiteral("Подать заявку на кредит"));layout->addWidget(request);connect(request,&QPushButton::clicked,this,[this,amount,term]{double assets=0;for(const auto& id:session->state.at("garage")){auto key=std::to_string(id.get<perekup::Money>());if(carsById.contains(key))assets+=perekup::num(carsById[key],"marketPrice",perekup::num(carsById[key],"price"));}bankAction([&](perekup::Bank& b){return b.request(amount->currentData().toLongLong(),term->currentData().toInt(),assets);});});auto accept=button(QStringLiteral("Получить одобренный кредит"));layout->addWidget(accept);connect(accept,&QPushButton::clicked,this,[this]{bankAction([](perekup::Bank& b){return b.accept();});});
 auto loan=new QComboBox;layout->addWidget(loan);auto repayment=new QLineEdit("10000");repayment->setPlaceholderText(QStringLiteral("Сумма погашения"));layout->addWidget(repayment);auto pay=button(QStringLiteral("Погасить выбранный заём"));layout->addWidget(pay);connect(pay,&QPushButton::clicked,this,[this,loan,repayment]{bool ok=false;auto amount=repayment->text().toLongLong(&ok);if(!ok||amount<1){showError(QStringLiteral("Введите положительную целую сумму."));return;}auto id=loan->currentData().toString().toStdString();bankAction([&](perekup::Bank& b){for(auto& entry:b.state["loans"])if(entry.value("id","")==id)return b.pay(entry,amount,b.now);return false;});});
 auto refresh=[this,balance,status,accept,loan]{if(closing||!session||!session->ready())return;const auto& state=session->state;balance->setText(QStringLiteral("На счёте: ")+money(state.at("balance").get<double>()));const auto& application=state.at("bank").at("application");auto stage=application.is_object()?application.value("status",""):"";status->setText(stage=="review"?QStringLiteral("Банк рассматривает заявку. Дождитесь решения."):stage=="approved"?QStringLiteral("Кредит одобрен. Можно получить деньги."):stage=="declined"?QStringLiteral("Банк отказал в заявке."):QStringLiteral("Выберите сумму и срок кредита."));accept->setEnabled(stage=="approved");auto selected=loan->currentData();loan->clear();for(const auto& entry:state.at("bank").at("loans"))if(entry.value("status","")=="active")loan->addItem(qs(entry.value("id",""))+" · "+money(perekup::Bank::debt(entry)),qs(entry.value("id","")));auto index=loan->findData(selected);if(index>=0)loan->setCurrentIndex(index);};auto timer=new QTimer(body);connect(timer,&QTimer::timeout,body,refresh);timer->start(1000);refresh();layout->addStretch();open("bank",QStringLiteral("Банк"),body,QSize(500,540));}
 void garageApp(){auto body=new QWidget;auto layout=new QVBoxLayout(body);auto summary=new QLabel;summary->setWordWrap(true);layout->addWidget(summary);auto scroll=new QScrollArea;scroll->setWidgetResizable(true);auto list=new QWidget;auto rows=new QVBoxLayout(list);scroll->setWidget(list);layout->addWidget(scroll);auto refresh=[this,summary,rows]{if(closing||!session||!session->ready())return;while(auto item=rows->takeAt(0)){delete item->widget();delete item;}const auto& state=session->state;summary->setText(QStringLiteral("Автомобилей: %1 · Мест в гараже: %2").arg(qulonglong(state.at("garage").size())).arg(state.value("garageCapacity",1)));for(const auto& id:state.at("garage")){auto key=std::to_string(id.get<perekup::Money>());if(!carsById.contains(key))continue;auto label=new QLabel(qs(carsById[key].value("name","")));label->setWordWrap(true);rows->addWidget(label);const auto& vehicles=state.at("transport").at("vehicles");if(vehicles.contains(key)){const auto& v=vehicles[key];auto city=v.value("cityId",homeCity);auto text=citiesById.contains(city)?qs(citiesById[city].value("name","")):QString();if(perekup::num(v,"debt"))text+=QStringLiteral(" · Долг за парковку: ")+money(perekup::num(v,"debt"));rows->addWidget(new QLabel(text));}}if(state.at("garage").empty())rows->addWidget(new QLabel(QStringLiteral("Пока нет автомобилей.")));rows->addStretch();};auto timer=new QTimer(body);connect(timer,&QTimer::timeout,body,refresh);timer->start(2000);refresh();open("garage",QStringLiteral("Гараж"),body,QSize(560,480));}
 void settings(){auto body=new QWidget;auto l=new QVBoxLayout(body);auto heading=new QLabel(QStringLiteral("Экран и оформление"));heading->setObjectName("heading");l->addWidget(heading);auto resolutions=new QComboBox;for(const auto& size:{QSize(1280,720),QSize(1920,1080),QSize(2560,1440),QSize(2560,1080),QSize(3440,1440),QSize(3840,2160),QSize(5120,1440)})resolutions->addItem(QString("%1 × %2").arg(size.width()).arg(size.height()),size);l->addWidget(resolutions);auto fullscreen=button(QStringLiteral("Полный экран")),windowed=button(QStringLiteral("Оконный режим"));l->addWidget(fullscreen);l->addWidget(windowed);auto recommendation=new QLabel;recommendation->setWordWrap(true);l->addWidget(recommendation);auto hint=[resolutions,recommendation]{auto size=resolutions->currentData().toSize();recommendation->setText(QStringLiteral("Для чётких обоев используйте изображение %1 × %2 пикселей.").arg(size.width()).arg(size.height()));};connect(resolutions,qOverload<int>(&QComboBox::currentIndexChanged),this,hint);hint();connect(fullscreen,&QPushButton::clicked,this,[this]{showFullScreen();});connect(windowed,&QPushButton::clicked,this,[this,resolutions]{showNormal();resize(resolutions->currentData().toSize());});auto wallpaper=button(QStringLiteral("Загрузить свои обои"));l->addWidget(wallpaper);connect(wallpaper,&QPushButton::clicked,this,[this]{auto path=QFileDialog::getOpenFileName(this,QStringLiteral("Выберите обои"),QString(),"Images (*.png *.jpg *.jpeg *.webp)");if(path.isEmpty())return;QPixmap image(path);if(image.isNull()){showError(QStringLiteral("Не удалось открыть изображение."));return;}QDir().mkpath(root+"/saves");QSaveFile file(root+"/saves/wallpaper.png");if(!file.open(QIODevice::WriteOnly)||!image.save(&file,"PNG")||!file.commit()){showError(QStringLiteral("Не удалось сохранить обои."));return;}preferences["wallpaper"]="saves/wallpaper.png";if(!savePreferences()){showError(QStringLiteral("Не удалось сохранить настройки."));return;}desktop->setWallpaper(root+"/saves/wallpaper.png");});l->addStretch();open("settings",QStringLiteral("Настройки"),body,QSize(530,450));}
 void clock(){auto body=new QWidget;auto l=new QVBoxLayout(body);auto face=new QLabel;face->setAlignment(Qt::AlignCenter);face->setStyleSheet("font-size:48px");l->addWidget(face);auto timer=new QTimer(body);connect(timer,&QTimer::timeout,body,[this,face]{face->setText(QDateTime::fromMSecsSinceEpoch(gameClock.gameMs).toString("HH:mm:ss"));});timer->start(250);open("clock",QStringLiteral("Часы"),body,QSize(450,280));}
public:
 void smokeTest(){market();open("calc",QStringLiteral("Калькулятор"),new CalculatorView,QSize(350,420));QTimer::singleShot(300,this,[this]{QApplication::quit();});}
 ~Shell()override{if(closingSave.valid())closingSave.wait();for(const auto& item:windows)QObject::disconnect(item.second,nullptr,this,nullptr);}
 bool initializeGame(){
  Json cities=Json::object(),cars=Json::object();std::string home;
  for(const auto& city:catalog.at("cities")){auto id=city.at("id").get<std::string>();cities[id]=city;if(city.value("name","")=="Москва")home=id;}
  for(const char* group:{"cars","tradeCars"})if(catalog.contains(group))for(const auto& car:catalog[group])cars[std::to_string(car.at("id").get<perekup::Money>())]=car;
  QFile stock(root+"/data/commerce.json");if(stock.open(QIODevice::ReadOnly)){auto bytes=stock.readAll();auto data=Json::parse(bytes.constData(),bytes.constData()+bytes.size());for(const auto& car:data.at("cars"))cars[std::to_string(car.at("id").get<perekup::Money>())]=car;for(const auto& offer:data.at("offers"))offersById[offer.at("id").get<std::string>()]=offer;}
  citiesById=cities;carsById=cars;homeCity=home;
  session=std::make_unique<perekup::Session>(std::filesystem::u8path(root.toUtf8().constData()),cities,cars,home);
  try{auto loaded=session->load();if(loaded.status==perekup::LoadStatus::LegacyAvailable){showError(QStringLiteral("Найдено сохранение предыдущей версии. Перенос этого формата ещё не подключён в сборке разработки. Исходные данные сохранены."));return false;}
   if(loaded.status==perekup::LoadStatus::Corrupt){auto answer=QMessageBox::question(this,QStringLiteral("Повреждено сохранение"),QStringLiteral("Сохранение не удалось прочитать. Сохранить его копию и начать новую игру?"),QMessageBox::Yes|QMessageBox::No,QMessageBox::No);if(answer!=QMessageBox::Yes)return false;session->preserveAndReset();}
   if(loaded.status==perekup::LoadStatus::RecoveredPrevious)QMessageBox::information(this,QStringLiteral("Сохранение восстановлено"),QStringLiteral("Основное сохранение недоступно. Загружена предыдущая копия."));
  }catch(const std::exception& e){showError(QStringLiteral("Не удалось загрузить игру. Данные не изменены.\n")+QString::fromUtf8(e.what()));return false;}
  if(!session->ready()){
   QDialog welcome(this);welcome.setWindowTitle(QStringLiteral("Добро пожаловать в Perekup"));auto layout=new QVBoxLayout(&welcome);auto intro=new QLabel(QStringLiteral("Это игра про перекупа: покупайте автомобили, оценивайте их состояние и зарабатывайте на продаже.\n\nВыберите ник и придумайте подпись из четырёх заглавных латинских букв. Запомните её: при подписании договора её нужно вводить самостоятельно. Напоминание стоит 10 000 ₽."));intro->setWordWrap(true);layout->addWidget(intro);auto form=new QFormLayout;auto nickname=new QLineEdit;nickname->setMaxLength(32);auto signature=new QLineEdit;signature->setMaxLength(4);signature->setValidator(new QRegularExpressionValidator(QRegularExpression("[A-Z]{0,4}"),signature));signature->setPlaceholderText("ABCD");form->addRow(QStringLiteral("Ник"),nickname);form->addRow(QStringLiteral("Подпись"),signature);layout->addLayout(form);auto errors=new QLabel;errors->setWordWrap(true);layout->addWidget(errors);auto buttons=new QDialogButtonBox(QDialogButtonBox::Ok|QDialogButtonBox::Cancel);layout->addWidget(buttons);connect(buttons,&QDialogButtonBox::rejected,&welcome,&QDialog::reject);connect(buttons,&QDialogButtonBox::accepted,&welcome,[&]{try{session->create(nickname->text().trimmed().toUtf8().toStdString(),signature->text().toUtf8().toStdString(),QDateTime::currentMSecsSinceEpoch());welcome.accept();}catch(const std::exception&){errors->setText(QStringLiteral("Проверьте ник (2–32 символа), подпись (4 буквы A–Z) и возможность записи в папку игры."));}});welcome.resize(520,350);if(welcome.exec()!=QDialog::Accepted)return false;
  }
  gameClock.gameMs=session->state.at("gameMs").get<qint64>();gameClock.lastRealMs=QDateTime::currentMSecsSinceEpoch();return true;
 }
 explicit Shell(const QString& directory):root(directory){QFile input(root+"/data/catalog.json");if(!input.open(QIODevice::ReadOnly))throw std::runtime_error("Missing data/catalog.json");auto data=input.readAll();catalog=Json::parse(data.constData(),data.constData()+data.size());QFile settingsFile(settingsPath());if(settingsFile.open(QIODevice::ReadOnly))preferences=QJsonDocument::fromJson(settingsFile.readAll()).object();desktop=new Desktop;setCentralWidget(desktop);desktop->setWallpaper(root+"/"+preferences.value("wallpaper").toString("assets/wallpaper.jpg"));setWindowTitle("Perekup — native development build");
 dock=new QWidget(desktop->viewport());dock->setObjectName("dock");auto bar=new QHBoxLayout(dock);auto add=[&](const QString& title,auto callback){auto b=button(title);bar->addWidget(b);connect(b,&QPushButton::clicked,this,callback);};add(QStringLiteral("Авторынок"),[this]{market();});add(QStringLiteral("Гараж"),[this]{garageApp();});add(QStringLiteral("Банк"),[this]{bankApp();});add(QStringLiteral("Календарь"),[this]{open("calendar",QStringLiteral("Календарь"),new QCalendarWidget,QSize(470,340));});add(QStringLiteral("Калькулятор"),[this]{open("calc",QStringLiteral("Калькулятор"),new CalculatorView,QSize(350,420));});add(QStringLiteral("Часы"),[this]{clock();});add(QStringLiteral("Змейка"),[this]{open("snake",QStringLiteral("Змейка"),new SnakeView,QSize(480,530));});add(QStringLiteral("Настройки"),[this]{settings();});add(QStringLiteral("Выйти"),[this]{close();});time=new QLabel;bar->addWidget(time);auto timer=new QTimer(this);connect(timer,&QTimer::timeout,this,[this]{if(closing||runtimeFailed||!session||!session->ready())return;gameClock.gameOver=session->state.at("marketRisks").at("seizures").size()>=5;gameClock.update(QDateTime::currentMSecsSinceEpoch());try{perekup::tickRuntime(session->state,gameClock.gameMs,citiesById,carsById,offersById,homeCity);}catch(const std::exception& e){runtimeFailed=true;gameClock.gameMs=session->state.at("gameMs").get<qint64>();showError(QStringLiteral("Обновление игрового времени приостановлено.\n")+QString::fromUtf8(e.what()));}if(autosave.valid()&&autosave.wait_for(std::chrono::milliseconds(0))==std::future_status::ready){auto completed=autosave;autosave={};try{completed.get();}catch(const std::exception& e){showError(QStringLiteral("Автосохранение не удалось. Прогресс остаётся в памяти; следующая попытка — через 30 секунд.\n")+QString::fromUtf8(e.what()));}autosave={};}
 if(!runtimeFailed&&++autosaveTicks>=30){autosaveTicks=0;if(!autosave.valid()){try{autosave=session->saveSnapshot(session->state);}catch(const std::exception& e){showError(QStringLiteral("Не удалось подготовить автосохранение.\n")+QString::fromUtf8(e.what()));}}}
 time->setText(QDateTime::fromMSecsSinceEpoch(gameClock.gameMs).toString("dd.MM HH:mm"));positionDock();});timer->start(1000);dock->show();resize(1280,720);}
protected:
 void resizeEvent(QResizeEvent* e)override{QMainWindow::resizeEvent(e);positionDock();}
 void closeEvent(QCloseEvent* e)override{
 if(closeAllowed||!session||!session->ready()){e->accept();return;}e->ignore();if(closing)return;
 if(!savePreferences()){showError(QStringLiteral("Не удалось сохранить настройки. Проверьте доступ к папке игры."));return;}
 auto snapshot=session->state;snapshot["gameMs"]=gameClock.gameMs;closing=true;setEnabled(false);
 try{closingSave=session->saveSnapshot(snapshot);}catch(const std::exception& error){closing=false;setEnabled(true);showError(QStringLiteral("Не удалось подготовить сохранение. Выход отменён.\n")+QString::fromUtf8(error.what()));return;}auto poll=new QTimer(this);
 connect(poll,&QTimer::timeout,this,[this,poll]{if(closingSave.wait_for(std::chrono::milliseconds(0))!=std::future_status::ready)return;poll->stop();poll->deleteLater();try{closingSave.get();closeAllowed=true;close();}catch(const std::exception& e){closing=false;setEnabled(true);showError(QStringLiteral("Не удалось сохранить игру. Выход отменён.\n")+QString::fromUtf8(e.what()));}});poll->start(40);
 }
};
int main(int argc,char** argv){QApplication app(argc,argv);app.setApplicationName("Perekup");app.setStyleSheet("QWidget{font-family:'Segoe UI';font-size:12px;color:#263036;}QMdiSubWindow{background:#f7f8f5;}QPushButton{background:#14796f;color:white;border:0;border-radius:4px;padding:7px 11px;}QPushButton:hover{background:#21877d;}QLineEdit,QComboBox{padding:7px;border:1px solid #dce1de;border-radius:5px;background:white;}QFrame#card{border:1px solid #dce1de;border-radius:6px;background:white;}QLabel#price{color:#14796f;font-size:19px;font-weight:600;}QWidget#sidebar,QWidget#dock{background:#242c35;border-radius:8px;}QWidget#sidebar QLabel,QWidget#dock QLabel{color:#dbe5e4;}QLabel#heading{font-size:22px;}");try{QString root=argc>1?QString::fromLocal8Bit(argv[1]):QCoreApplication::applicationDirPath();Shell shell(root);shell.showFullScreen();if(argc>2&&QString::fromLocal8Bit(argv[2])=="--smoke-test"){shell.smokeTest();return app.exec();}if(!shell.initializeGame())return 0;return app.exec();}catch(const std::exception& e){QMessageBox::critical(nullptr,"Perekup",QString::fromUtf8(e.what()));return 1;}}
