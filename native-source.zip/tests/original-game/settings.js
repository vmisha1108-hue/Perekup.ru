'use strict';

var OS_STYLES={perekup:{label:'Perekup OS',theme:'light',wallpapers:[{id:'embankment',label:'Набережная'},{id:'aurora',label:'Сияние'}]}};
var appearance=readSaved('appearance',{});
function normalizeAppearance(value){
    value=value && typeof value==='object'?value:{};
    var result={version:2,os:'perekup',themes:{},wallpapers:{}};
    Object.keys(OS_STYLES).forEach(function(os){
        var style=OS_STYLES[os],theme=value.themes && value.themes[os],wall=value.wallpapers && value.wallpapers[os];
        result.themes[os]=['light','dark'].indexOf(theme)!==-1?theme:style.theme;
        result.wallpapers[os]=style.wallpapers.some(function(item){return item.id===wall;})?wall:style.wallpapers[0].id;
    });
    return result;
}
appearance=normalizeAppearance(appearance);
function applyAppearance(){
    var root=document.documentElement;
    root.dataset.os=appearance.os;root.dataset.theme=appearance.themes[appearance.os];
    root.dataset.wallpaper=appearance.wallpapers[appearance.os];
    root.style.setProperty('--wallpaper-image','url("'+wallpaperPath(root.dataset.wallpaper)+'")');
}
applyAppearance();
function changeAppearance(kind,value){
    if(kind==='theme' && ['light','dark'].indexOf(value)!==-1)appearance.themes[appearance.os]=value;
    else if(kind==='wallpaper' && OS_STYLES[appearance.os].wallpapers.some(function(item){return item.id===value;}))appearance.wallpapers[appearance.os]=value;
    else return;
    applyAppearance();writeSaved('appearance',appearance);renderAppearanceControls();
    document.querySelectorAll('.window.open').forEach(clampWindow);
}
function renderAppearanceControls(){
    var os=appearance.os;
    document.querySelectorAll('[name="settingsTheme"]').forEach(function(input){input.checked=input.value===appearance.themes[os];});
    var grid=$('settingsWallpapers');
    if(grid.dataset.os!==os){
        grid.dataset.os=os;
        grid.innerHTML=OS_STYLES[os].wallpapers.map(function(w){return '<label class="wallpaper-choice"><input type="radio" name="settingsWallpaper" value="'+w.id+'"><img class="wallpaper-swatch" src="'+wallpaperPath(w.id)+'" alt="" loading="lazy" decoding="async"><span>'+w.label+'</span></label>';}).join('');
    }
    grid.querySelectorAll('input').forEach(function(input){input.checked=input.value===appearance.wallpapers[os];});
}
function renderSettings(){
    if(!hasPlayerIdentity())return;
    $('settingsPlayerName').textContent=playerIdentity.nickname;
    $('settingsAvatar').textContent=Array.from(playerIdentity.nickname)[0].toUpperCase();
    $('settingsNickname').value=playerIdentity.nickname;
    $('settingsSignaturePreview').innerHTML=signatureHtml(playerIdentity.signature,'Ваша текущая подпись');
    renderAppearanceControls();
}
function editPlayerIdentity(nickname,signature){
    nickname=String(nickname).trim().replace(/\s+/g,' ');
    if(!hasPlayerIdentity() || !validNickname(nickname))return 'Ник должен содержать от 2 до 32 символов.';
    if(!validSignature(signature))return 'Подпись — ровно 4 заглавные латинские буквы.';
    var identity={version:1,nickname:nickname,signature:JSON.parse(JSON.stringify(signature))};
    try{writeSaved('playerIdentity',identity);}catch(e){return 'Не удалось сохранить профиль. Проверьте хранилище браузера.';}
    playerIdentity=identity;
    // The profile may share an object with a signed contract. Replace it,
    // so historic signatures and names remain exactly as originally signed.
    contractBook.profile=Object.assign({},contractBook.profile,{fullName:nickname,signature:JSON.parse(JSON.stringify(identity.signature))});
    pending.forEach(function(item){if(item.contract){item.contract.fields.fullName=nickname;item.contract.fields.signature=nickname;item.contract.acknowledged=false;}});
    saveContracts();save();renderSettings();
    if(chat && chat.stage==='contract')renderContractForm(true);
    return '';
}
function finishSignatureEditing(){
    $('settingsSignatureWord').value='';$('settingsSignatureEditor').hidden=true;$('settingsSignatureError').textContent='';
}
function initSettings(){
    $('settingsAppearance').addEventListener('change',function(event){
        var input=event.target;
        if(input.name==='settingsTheme')changeAppearance('theme',input.value);
        if(input.name==='settingsWallpaper')changeAppearance('wallpaper',input.value);
    });
    $('settingsNicknameForm').addEventListener('submit',function(event){
        event.preventDefault();var error=editPlayerIdentity($('settingsNickname').value,playerIdentity.signature);$('settingsNicknameError').textContent=error;
        if(!error)toast('Ник сохранён. Подписанные договоры сохранили прежние данные.');
    });
    $('settingsEditSignature').addEventListener('click',function(){finishSignatureEditing();$('settingsSignatureEditor').hidden=false;});
    bindWordSignature($('settingsSignatureWord'));
    $('settingsCancelSignature').addEventListener('click',finishSignatureEditing);
    $('settingsClearSignature').addEventListener('click',function(){$('settingsSignatureWord').value='';$('settingsSignatureWord').focus();});
    $('settingsSignatureForm').addEventListener('submit',function(event){
        event.preventDefault();var signature=$('settingsSignatureWord').value.toUpperCase();
        var error=validWordSignature(signature)?editPlayerIdentity(playerIdentity.nickname,signature):'Подпись — ровно 4 заглавные латинские буквы, например MIKE.';$('settingsSignatureError').textContent=error;
        if(!error){finishSignatureEditing();toast('Новая подпись сохранена для следующих договоров.');}
    });
    $('settingsReset').addEventListener('click',function(){
        if(!confirm('Сбросить игровой прогресс? Деньги, машины, долги, встречи и договоры будут удалены. Ник, подпись, оформление и музыка сохранятся.'))return;
        resetGameProgress(true);finishSignatureEditing();renderSettings();toast('Прогресс сброшен. Вы начинаете со 100 000 ₽.');
    });
    // Use one original icon family across all three desktop styles.
    document.querySelectorAll('.window .wi').forEach(function(el){var id=el.closest('.window').id.replace('win-','');if(APP_ICON_PATHS[id] || APP_ICON_ART[id]){el.dataset.app=id;el.innerHTML=appIconSvg(id);}});
    renderSettings();
}

// Small interface symbols keep their outline style; application artwork is layered and filled.
var APP_ICON_PATHS={
    chat:'<path d="M3 3h18v13H9l-6 5z"/>',
    profile:'<circle cx="12" cy="7" r="4"/><path d="M4 22v-3a8 8 0 0 1 16 0v3"/>',
    location:'<path d="M19 9c0 5-7 13-7 13S5 14 5 9a7 7 0 0 1 14 0z"/><circle cx="12" cy="9" r="2"/>',
    wallet:'<path d="M3 5h17v16H3zM3 5l15-3v3m-4 6h7v5h-7z"/>'
};
var GARAGE_ICON_ART='<path fill="#547088" d="m4 17 20-11 20 11v27H4z"/><path fill="url(#app-paper)" d="M7 16h34v26H7z"/><path fill="#bbc9d4" d="M37 16h4v26h-4z"/><path fill="#fff" d="M1 16 24 3l23 13-2 4L24 8 3 20z"/><path fill="#9db2c4" d="m3 20 21-12 21 12v2L24 11 3 23z"/><path fill="url(#app-metal)" d="M13 24h22v18H13z"/><path stroke="#8c9fae" stroke-width="1.5" d="M15 28h18m-18 4h18m-18 4h18"/><path fill="#c6d3dc" d="M20 38h8v2h-8z"/><path fill="#889daa" d="M4 42h40v3H4z"/>';
var APP_ICON_ART={
    market:'<path fill="#fff" d="m9 20 4-11a4 4 0 0 1 4-3h14a4 4 0 0 1 4 3l4 11 4 5v12H5V25z"/><path fill="var(--icon-color,#ff6254)" d="m13 19 3-10h16l3 10z"/><path fill="#fff" d="M3 18h6v4H3zm36 0h6v4h-6z"/><rect fill="url(#app-paper)" x="5" y="33" width="8" height="10" rx="3"/><rect fill="url(#app-paper)" x="35" y="33" width="8" height="10" rx="3"/><rect fill="var(--icon-color,#ff6254)" x="9" y="26" width="8" height="5" rx="2.5"/><rect fill="var(--icon-color,#ff6254)" x="31" y="26" width="8" height="5" rx="2.5"/><path stroke="#dce5eb" stroke-width="2" d="M18 34h12"/>',
    shop:GARAGE_ICON_ART,
    garage:GARAGE_ICON_ART,
    calc:'<rect fill="#bacddd" x="9" y="4" width="30" height="42" rx="4"/><rect fill="url(#app-paper)" x="8" y="3" width="30" height="41" rx="4"/><rect fill="#377ba9" x="12" y="8" width="22" height="9" rx="1"/><path fill="#4489b3" d="M13 9h20v2H13z"/><g fill="#4684ae"><rect x="12" y="21" width="5" height="5" rx=".7"/><rect x="20.5" y="21" width="5" height="5" rx=".7"/><rect x="29" y="21" width="5" height="5" rx=".7"/><rect x="12" y="29" width="5" height="5" rx=".7"/><rect x="20.5" y="29" width="5" height="5" rx=".7"/><rect x="29" y="29" width="5" height="13" rx=".7"/><rect x="12" y="37" width="5" height="5" rx=".7"/><rect x="20.5" y="37" width="5" height="5" rx=".7"/></g>',
    calendar:'<rect fill="#b93836" x="3" y="11" width="42" height="34" rx="5"/><rect fill="url(#app-paper)" x="3" y="10" width="42" height="33" rx="4"/><path fill="#fff" d="M3 14a4 4 0 0 1 4-4h34a4 4 0 0 1 4 4v5H3z"/><g fill="#fff"><rect x="11" y="2" width="3" height="11" rx="1.5"/><rect x="34" y="2" width="3" height="11" rx="1.5"/></g><path fill="#233449" d="m12 23 5-3h3v19h-4V25l-4 2zm14-3h12v4h-8v4c8-2 12 3 9 8-2 5-10 4-13 2l1-4c6 4 11-2 6-3-2-1-4 0-6 1z"/>',
    clock:'<circle fill="#bfd1df" cx="25" cy="25" r="23"/><circle fill="url(#app-paper)" cx="24" cy="23" r="22"/><g stroke="#526575" stroke-width="1.5" stroke-linecap="round"><path d="M24 5v2m0 32v2M6 23h2m32 0h2M15 7.4l1 1.7m16 27.8 1 1.7M8.4 14l1.7 1m27.8 16 1.7 1M8.4 32l1.7-1m27.8-16 1.7-1M15 38.6l1-1.7m16-27.8 1-1.7"/></g><path stroke="#283e51" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round" d="M24 11v13l10 7"/><circle fill="#283e51" cx="24" cy="24" r="2.2"/>',
    bank:'<path fill="#278657" d="M3 42h42v4H3z"/><path fill="#fff" d="m2 14 22-12 22 12z"/><path fill="#d7e8dd" d="M4 14h40v4H4z"/><circle fill="#469b70" cx="24" cy="10" r="2.7"/><path fill="url(#app-paper)" d="M8 18h6v20H8zm13 0h6v20h-6zm13 0h6v20h-6z"/><path fill="#c4dcd0" d="M11 19h3v17h-3zm13 0h3v17h-3zm13 0h3v17h-3z"/><path fill="#fff" d="M6 18h10v3H6zm13 0h10v3H19zm13 0h10v3H32zM6 36h10v3H6zm13 0h10v3H19zm13 0h10v3H32zM5 39h38v3H5z"/><path fill="#d7e8dd" d="M2 42h44v3H2z"/>',
    travel:'<rect fill="url(#app-paper)" x="1" y="7" width="31" height="29" rx="2.5"/><path fill="#d8ece1" d="M1 33h31v3H1z"/><path fill="#fff" d="M33 19h8l6 12v8H33z"/><path fill="#429e6b" d="M36 22h4l4 9h-8z"/><path fill="#e0eee7" d="M34 33h13v6H34z"/><rect fill="#b8d7c4" x="36" y="33" width="4" height="2" rx="1"/><circle fill="#2d8c58" cx="9" cy="40" r="5.5"/><circle fill="#fff" cx="9" cy="40" r="3.5"/><circle fill="#2d8c58" cx="39" cy="40" r="5.5"/><circle fill="#fff" cx="39" cy="40" r="3.5"/>',
    documents:'<path fill="#c0d3e3" d="M8 4h22l12 12v29H8z"/><path fill="url(#app-paper)" d="M6 2h23l11 12v29H6z"/><path fill="#b0c6d6" d="M28 3v13h12z"/><path fill="#e7eff6" d="M29 2v12h11z"/><g stroke="#9db4c6" stroke-width="2.5" stroke-linecap="round"><path d="M13 17h11m-11 7h20m-20 6h20m-20 6h14"/></g>',
    help:'<path fill="url(#app-paper)" d="M10 10C12-1 37-2 38 11c1 8-9 10-10 16v3h-8v-4c0-9 10-10 10-15 0-5-11-6-13 2z"/><circle fill="url(#app-paper)" cx="24" cy="40" r="4.5"/>',
    settings:'<path fill="url(#app-paper)" fill-rule="evenodd" d="m20 1-1 6-5 2-5-3-6 6 3 5-2 5-4 1v8l6 1 2 5-3 5 6 6 5-3 5 2 1 4h8l1-6 5-2 5 3 6-6-3-5 2-5 4-1v-8l-6-1-2-5 3-5-6-6-5 3-5-2-1-4zm4 14a9 9 0 1 0 0 18 9 9 0 0 0 0-18z" transform="translate(3 2) scale(.88)"/><circle fill="#768a9a" cx="24.1" cy="23.1" r="5.5"/><circle fill="#dae3ea" cx="24.1" cy="23.1" r="3"/>'
};
APP_ICON_ART.import=APP_ICON_ART.travel;
APP_ICON_ART.dealer=APP_ICON_ART.shop;
APP_ICON_ART.business=APP_ICON_ART.bank;
Object.assign(APP_ICON_PATHS,{
market:'<path d="m3 14 2-6h14l2 6v5h-3v-2H6v2H3zM5 12h14M7 8l1-3h8l1 3"/><circle cx="7" cy="14" r=".7"/><circle cx="17" cy="14" r=".7"/>',
garage:'<path d="M3 20V9l9-6 9 6v11M7 20V11h10v9M8 15h8M8 18h8"/>',
travel:'<path d="m3 5 6-2 6 2 6-2v16l-6 2-6-2-6 2zm6-2v16m6-14v16"/>',
bank:'<path d="m3 8 9-5 9 5zM4 21h16M5 18h14M6 10v6m6-6v6m6-6v6"/>',
documents:'<path d="M6 3h9l4 4v14H6zM14 3v5h5M9 12h7m-7 4h7"/>',
settings:'<path d="m9 3-1 3-3 1-2 3 2 3v4l3 1 2 3h4l2-3 3-1v-4l2-3-2-3-3-1-1-3z"/><circle cx="12" cy="12" r="3"/>',
calendar:'<rect x="4" y="5" width="16" height="16" rx="2"/><path d="M8 3v4m8-4v4M4 10h16m-11 5h6"/>',
clock:'<circle cx="12" cy="12" r="9"/><path d="M12 6v6l4 2"/>',
help:'<circle cx="12" cy="12" r="9"/><path d="M9 9a3 3 0 1 1 4 3c-1 1-1 1-1 3m0 3h.01"/>',
calc:'<rect x="5" y="2" width="14" height="20" rx="2"/><path d="M8 6h8M8 11h1m6 0h1m-8 4h1m6 0h1m-8 4h1m6 0h1"/>',
shop:'<path d="M4 10v11h16V10M2 10l3-7h14l3 7zM9 21v-7h6v7"/>',
business:'<rect x="3" y="7" width="18" height="14" rx="2"/><path d="M8 7V3h8v4M3 12h18m-9-2v4"/>',
import:'<path d="M4 14 2 18l10 4 10-4-2-4-8-3zM7 12V5h10v7M10 5V2h4v3"/>',
dealer:'<path d="M3 21V7l9-4 9 4v14M7 10h3m4 0h3m-10 4h3m4 0h3m-8 7v-4h6v4"/>'
});
var appIconSequence=0;
function appIconSvg(id){
    return '<svg class="app-icon" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">'+(APP_ICON_PATHS[id] || '')+'</svg>';
}
function wallpaperPath(id){if(id==='embankment')return 'wallpapers/embankment.webp';return 'wallpapers/'+id+(['ribbons','valley','facets'].indexOf(id)!==-1?'.jpg':'.svg');}
